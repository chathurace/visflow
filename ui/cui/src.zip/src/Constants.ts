export const nodeHeight: number = 50;
export const nodeWidth: number = 100;
export const edgeHeight: number = 100;
export const hGap: number = 100;
export const vGap: number = 50;
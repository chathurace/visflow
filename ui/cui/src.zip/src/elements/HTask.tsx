import React, { ChangeEvent } from "react";
import { nodeHeight, nodeWidth } from "../Constants";
import { HCanvas } from "../components/HCanvas";
import { HEdge } from "./HEdge";
import { HNode } from "./HNode";

export class HTask extends HNode {

    logMessage: string = "";

    testAdd() {
        
    }

    viewProperties = () => {
        this.canvas.setSelectedNode(this)
    }

    draw(): JSX.Element {
        return <>
        <rect x={this.x} y={this.y} rx="15" ry="15" width={this.width} height={this.height} fill="lightblue" stroke="white" strokeWidth="1" onClick={() => this.viewProperties()} onAuxClick={() => this.delete()}/>
        <text x={this.midX} y={this.midY} dominantBaseline="middle" textAnchor="middle" fill="black">{this.label}</text>
        </>;
    }

    getPropertiesView(): JSX.Element {
        return <div>
            {/* <label>Label</label>
            <input type="text" value={this.logMessage} onBlur={(e) => this.logMessage = e.target.value}/> */}
            <HLogPropertiesView logNode={this}/>
        </div>
    }
}

export const addTask = (edge: HEdge) => {
    let hTask = new HTask(edge.block, edge.canvas);
    hTask.label = "Log";
    hTask.connectTo(edge);
    edge.canvas.setSelectedEdge(null);
    edge.canvas.render();
}

interface HLogPropertiesViewP {
    logNode: HTask;
}

export const HLogPropertiesView: React.FC<HLogPropertiesViewP> = ({logNode}) => {

    const [logMessage, setLogMessage] = React.useState<string>("some props");

    const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
        console.log("Typed something...");
        setLogMessage(e.target.value)
    };

    return <div>
            <label>Label</label>
            {/* <input type="text" value={logMessage} onChange={(e: ChangeEvent<HTMLInputElement>) => {setLogMessage(e.target.value)}}/> */}
            <input type="text" value={logMessage} onChange={handleChange}/>
            {/* onBlur={(e) => logNode.logMessage = e.target.value} */}
        </div>
};
